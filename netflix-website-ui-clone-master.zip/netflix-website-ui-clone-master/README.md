# Netflix-website-ui-clone
This is simplified front end clone of Netflix creates using Javascript ,HTML ,CSS and using moviedb API .
<img src = "https://github.com/1SiddhantSingh/netflix-website-ui-clone/blob/master/Screenshot%202023-04-16%20094555.png">
<img src="https://github.com/1SiddhantSingh/netflix-website-ui-clone/blob/master/Screenshot%202023-04-15%20201329.png">
